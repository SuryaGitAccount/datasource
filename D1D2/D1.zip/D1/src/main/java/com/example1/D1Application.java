package com.example1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D1Application {

	public static void main(String[] args) {
		SpringApplication.run(D1Application.class, args);
	}

}
