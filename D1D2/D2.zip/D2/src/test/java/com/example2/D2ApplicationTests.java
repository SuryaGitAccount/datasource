package com.example2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
